# = = = PROJECTO DE FP - 2a parte = = = #
#
#  - Grupo XXX - 
# 
# . Aluno XXX
# . Aluno YYY
# . Aluno ZZZ

# = = = Modulos exteriores = = = # 

from robot import * # Modulo de comunicacao com o robot
# < Incluir aqui outros imports que ache necessarios >

# = = = Definicao de tipos = = = #

# - - Tipo objecto - - #

# < Incluir codigo aqui >


# - - Tipo direccao - - #

# < Incluir codigo aqui >


# - - Tipo posicao - - #

# < Incluir codigo aqui >


# - - Tipo mapa - - #

# < Incluir codigo aqui >


# - - Tipo caminho - - #

# < Incluir codigo aqui >


# - - Tipo estado - - #

# < Incluir codigo aqui >


# = = = Controlo do Robot = = = #

# controla_robot : robot -> str x estado
#
# controla_robot(e, r) deve, com base no seu estado interno, escolher e executar
# uma accao sobre o robot r, e actualizar o estado em conformidade.

def controla_robot(e, r):
    
# < Incluir codigo aqui >
        